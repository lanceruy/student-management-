-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2018 at 03:42 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fscience`
--

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `staffid` int(30) NOT NULL,
  `pswd` varchar(30) NOT NULL,
  `role` varchar(30) NOT NULL,
  `unit` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`fname`, `lname`, `staffid`, `pswd`, `role`, `unit`) VALUES
('MR.', 'LUKA', 1998, '35798874', 'LECTURER', 'COSC223'),
('boniface', 'Kipruto', 4597, '4590', 'LECTURER', 'OOP'),
('EDWIN', 'gogo', 4999, '4998', 'ADMIN', ''),
('HILARY', 'MWENDIA', 33931118, '9680', 'Finance manager', ''),
('DENNIS', 'KIBET', 35527543, '35527543', 'LECTURER', 'PYTHON');

-- --------------------------------------------------------

--
-- Table structure for table `stud_details`
--

CREATE TABLE `stud_details` (
  `year` int(1) NOT NULL DEFAULT '1',
  `fname` varchar(15) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `id` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` int(10) DEFAULT NULL,
  `coursecode` varchar(10) NOT NULL,
  `fee` int(10) NOT NULL DEFAULT '0',
  `feercvd` int(10) DEFAULT '0',
  `feebal` int(10) NOT NULL DEFAULT '0',
  `status` varchar(20) NOT NULL DEFAULT 'NOT CLEARED',
  `pswd` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_details`
--

INSERT INTO `stud_details` (`year`, `fname`, `lname`, `id`, `gender`, `email`, `contact`, `coursecode`, `fee`, `feercvd`, `feebal`, `status`, `pswd`) VALUES
(5, 'MIKE MUTINDA ', 'LUKA', 'EB1/27998', 'Male', 'miketish2017@gmail.com', 707205934, 'BSC ', 21500, 20000, 1500, 'CLEARED', '35798874'),
(3, 'Edwin', 'Ndungu', 'EB3/26774', 'Female', 'Edwin@gmail.com', 702255522, 'OOP', 25000, 18251, 6749, 'CLEARED', '34236921'),
(1, 'boniface', 'Kipruto', 'eb3/27731', 'Male', 'Bonifaceruy@gmail.com', 727903884, 'OOP', 0, 0, 0, 'NOT CLEARED', '4590'),
(1, 'boniface', 'Kipruto', 'eb3/277318', 'Male', 'Bonifaceruy@gmail.com', 727903884, 'OOP', 0, 0, 0, 'NOT CLEARED', '4590'),
(1, 'boniface', 'Kipruto', 'eb3/27734', 'Male', 'Bonifaceruy@gmail.com', 727903884, 'OOP', 0, 0, 0, 'NOT CLEARED', '4590'),
(1, 'boniface', 'Kipruto', 'eb3/27735', 'Male', 'Bonifaceruy@gmail.com', 727903884, 'OOP', 0, 0, 0, 'NOT CLEARED', '4590'),
(1, 'boniface', 'Kipruto', 'eb3/27736', 'Male', 'Bonifaceruy@gmail.com', 727903884, 'OOP', 0, 0, 0, 'NOT CLEARED', '4590'),
(1, 'boniface', 'Kipruto', 'eb3/27737', 'Male', 'Bonifaceruy@gmail.com', 727903884, 'OOP', 0, 0, 0, 'NOT CLEARED', '4590');

-- --------------------------------------------------------

--
-- Table structure for table `stud_results`
--

CREATE TABLE `stud_results` (
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `id` varchar(40) NOT NULL,
  `acsc224` int(30) DEFAULT NULL,
  `acsc225` int(30) DEFAULT NULL,
  `acsc231` int(30) DEFAULT NULL,
  `coms271` int(30) DEFAULT NULL,
  `cosc273` int(30) DEFAULT NULL,
  `zool233` int(30) DEFAULT NULL,
  `total` int(30) DEFAULT NULL,
  `grade` varchar(30) DEFAULT 'fail'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_results`
--

INSERT INTO `stud_results` (`fname`, `lname`, `id`, `acsc224`, `acsc225`, `acsc231`, `coms271`, `cosc273`, `zool233`, `total`, `grade`) VALUES
('Edwin', 'Ndungu', 'EB3/26774', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fail'),
('MIKE MUTINDA ', 'LUKA', 'EB1/27998', NULL, NULL, NULL, NULL, NULL, 87, NULL, 'fail'),
('boniface', 'Kipruto', 'eb3/27734', 90, 65, 75, 76, 71, 50, 427, 'PASSED'),
('boniface', 'Kipruto', 'eb3/27731', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fail'),
('boniface', 'Kipruto', 'eb3/27735', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fail'),
('boniface', 'Kipruto', 'eb3/27736', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fail'),
('boniface', 'Kipruto', 'eb3/27737', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fail'),
('boniface', 'Kipruto', 'eb3/277318', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fail');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`staffid`),
  ADD UNIQUE KEY `staffid` (`staffid`,`pswd`);

--
-- Indexes for table `stud_details`
--
ALTER TABLE `stud_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_results`
--
ALTER TABLE `stud_results`
  ADD KEY `id` (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `stud_results`
--
ALTER TABLE `stud_results`
  ADD CONSTRAINT `stud_results_ibfk_1` FOREIGN KEY (`id`) REFERENCES `stud_details` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
